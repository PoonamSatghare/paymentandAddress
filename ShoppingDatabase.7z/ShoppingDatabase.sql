use Training_19Sep18_Pune



create table Shopping(
FirstName nvarchar(20) ,
LastName nvarchar(20),
Mobile_Number nvarchar(10) primary key,
Email_Address nvarchar(50) ,
Pass nvarchar(20) not null,
SecurityQues nvarchar(100) ,
Answer nvarchar(30) 

 
);
drop table shopping;

create procedure InsertValues(
@FirstName nvarchar(20) ,
@LastName nvarchar(20),
@Mobile_Number nvarchar(10),
@Email_Address nvarchar(50) ,
@Pass nvarchar(20),
@SecurityQues nvarchar(100) ,
@Answer nvarchar(30) 
)
as
begin
	insert into Shopping
values(@FirstName ,@LastName ,@Mobile_Number,@Email_Address,@Pass, @SecurityQues, @Answer)
end


select * from shopping;



drop table shopping;

alter table Shopping 
alter column SecurityQues int;

create table SecurityQuestion(
id int identity(1,1),
question varchar(100),

);
insert into SecurityQuestion values('What month were you born?'),('What is your favorite colour'),('What is the first name of your best friend in high school?');


select * from Shopping





create table Address(
Mobile_Number nvarchar(10),
ord_FullName nvarchar(20),
ord_MobileNumber nvarchar(10),
Home_Address nvarchar(60) ,
City nvarchar(20),
StateOfCity nvarchar(20) ,
Country nvarchar(20) ,
Pincode int ,
foreign key(Mobile_Number) references shopping(Mobile_Number)
);

create procedure InsertAddress(
@Mobile_Number nvarchar(10),
@ord_FullName nvarchar(20),
@ord_MobileNumber nvarchar(10),
@Home_Address nvarchar(60) ,
@City nvarchar(20),
@StateOfCity nvarchar(20) ,
@Country nvarchar(20) ,
@Pincode int 
)
as
begin
	insert into Address
values(@Mobile_Number ,@ord_FullName ,@ord_MobileNumber,@Home_Address,@City, @StateOfCity, @Country, @Pincode)
end


delete from address;
select * from address;